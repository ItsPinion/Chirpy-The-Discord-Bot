ALTER TABLE user ADD `last_monthly` integer;--> statement-breakpoint
ALTER TABLE user ADD `last_yearly` integer;