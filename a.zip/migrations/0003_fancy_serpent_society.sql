ALTER TABLE `user` DROP COLUMN `last_monthly`;--> statement-breakpoint
ALTER TABLE `user` DROP COLUMN `last_yearly`;