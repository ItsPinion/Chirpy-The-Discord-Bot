CREATE TABLE `user` (
	`user_id` text PRIMARY KEY NOT NULL,
	`balance` integer
);
