ALTER TABLE user ADD `last_daily` integer;--> statement-breakpoint
ALTER TABLE user ADD `last_weekly` integer;--> statement-breakpoint
ALTER TABLE user ADD `last_monthly` integer;